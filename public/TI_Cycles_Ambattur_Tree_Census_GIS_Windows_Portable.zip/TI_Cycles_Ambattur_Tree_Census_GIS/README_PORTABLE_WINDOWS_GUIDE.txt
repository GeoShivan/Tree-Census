===============================================================================
TI CYCLES OF INDIA - AMBATTUR CAMPUS TREE CENSUS GIS
Portable Windows Package with Full Interactive GIS & All Panels
Client Delivery Version 2.0 (Census Survey 2024-2025)
===============================================================================

Tube Investments of India Limited (Murugappa Group)
Location: CTH Road / MTH Road, Ambattur Industrial Estate, Chennai, Tamil Nadu
Survey Dataset: 911 Surveyed Trees across ~14.8 Hectares Compound

HOW TO RUN:
-----------
1. Extract all contents of this ZIP archive to any folder on your Windows computer
   (e.g., C:\TI_Cycles_GIS or on a USB Drive).
2. Double-click "Launch_TI_Cycles_GIS.bat" to start the full application.
   (An instant lightweight local web server starts automatically and opens your browser).
3. No installation, administrator rights, Python, or Node.js required!

ALL APPLICATION PANELS INCLUDED:
--------------------------------
1. Interactive OpenLayers Webmap:
   - High-Resolution Satellite Basemap (Esri World Imagery)
   - Hybrid Satellite + Streets Overlay
   - OpenStreetMap & Dark Matter Basemaps
   - TIDC Campus Boundary & Sub-Zones
   - Dynamic Tree Points & Physical Crown Canopy Shade Buffers
   - Map Color-Coding by Health, Species, Family, DBH class, or Carbon Sequestration
   - Interactive Measurement Tools (Distance in meters / Area in sq. meters)
   - Real-time GPS Coordinate Display (WGS84 Lat/Lng + UTM Zone 44N projection)

2. Complete Sidebar Filter Panel:
   - Universal search box (Tree ID, Common name, Botanical name, Tamil name, Tag)
   - Quick filter chips (All Trees, Heritage >60cm DBH, Native, Stressed, High CO2)
   - Health condition filter chips (Healthy, Good, Fair, Stressed, Diseased, Critical)
   - Botanical species filter (all 56 species with specimen counts)
   - Taxonomic family filter (all 26 families with specimen counts)
   - Campus sector filter
   - Dendrometric sliders (DBH girth range, Tree height range, Min CO2 sequestration)
   - Native vs Exotic classification
   - Full Tree Directory list with live filtering

3. Attribute Table Drawer:
   - Full interactive table of all 911 surveyed trees
   - Sorting by Tree ID, Common Name, Botanical Name, Family, DBH, Height, Canopy, Health, CO2, Zone
   - Table-specific search and pagination (15, 25, 50, 100 rows)
   - One-click row zoom and tree selection
   - Direct CSV and GeoJSON export buttons

4. Analytics & Statistics Dashboard:
   - Overview KPIs: Total Trees (911), Annual Carbon Sink (tonnes CO2/yr), Total Biomass, Canopy Coverage, Asset Valuation (INR Lakhs)
   - Biodiversity Indices: Shannon-Wiener Diversity Index (H') and Simpson Index
   - Top 10 Dominant Botanical Species distribution horizontal bar charts
   - Health condition distribution breakdown
   - DBH girth size class structure
   - Campus sector tree density breakdown

5. Tree Detail Dossier & Metal Tag Generator:
   - Detailed inspection card with measurements, health rating, and arborist actions
   - GPS coordinates with Google Maps link
   - Field QR tree tag generator ready for on-site printing

6. Executive Printable Report:
   - Print-ready ISO 14001:2015 environmental audit compliance summary report

DATA FILES INCLUDED:
--------------------
- SourceFile/TreesPoint.geojson        : Original raw survey data in UTM 44N (EPSG:32644)
- SourceFile/TIDC_Boundary.geojson     : Original TIDC campus perimeter boundary
- TI_Cycles_Ambattur_Trees.geojson     : Web-ready GeoJSON in WGS84 (EPSG:4326)
- TI_Cycles_Campus_Boundary.geojson    : Campus Boundary GeoJSON
- TI_Cycles_Ambattur_Tree_Census.csv   : Complete tabular spreadsheet (Excel compatible)

COMPATIBILITY:
--------------
- Operating Systems: Windows 10, Windows 11, Windows Server (64-bit / 32-bit)
- Browsers: Microsoft Edge, Google Chrome, Mozilla Firefox, Brave
- GIS Software: QGIS, ArcGIS Pro, Google Earth Pro, AutoCAD Civil 3D

Contact: Environmental Sustainability & Campus Green Infrastructure Team
TI Cycles of India, Ambattur.
