@echo off
setlocal enabledelayedexpansion
title TI Cycles Ambattur - Tree Census GIS
color 0A

echo ===============================================================================
echo     TI CYCLES OF INDIA - AMBATTUR CAMPUS TREE CENSUS GIS
echo     Tube Investments of India Ltd. / Murugappa Group
echo     Census Survey 2024-2025 (911 Surveyed Trees)
echo ===============================================================================
echo.
echo Launching Full Interactive Tree Census Webmap GIS with All Panels...
echo.

set PORT=8899
set DIR=%~dp0

:: Check if PowerShell is available to launch a zero-dependency instant local web server
where powershell >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo Starting lightweight local server on http://localhost:!PORT!...
    start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "$p='!DIR!'; $s=[System.Net.HttpListener]::new(); $s.Prefixes.Add('http://localhost:!PORT!/'); try { $s.Start(); Start-Process 'http://localhost:!PORT!/index.html'; while ($s.IsListening) { $c=$s.GetContext(); $f=Join-Path $p ($c.Request.Url.LocalPath.TrimStart('/')); if (-not (Test-Path $f) -or (Get-Item $f).PSIsContainer) { $f=Join-Path $p 'index.html' }; if (Test-Path $f) { $b=[System.IO.File]::ReadAllBytes($f); $c.Response.ContentLength64=$b.Length; $e=[System.IO.Path]::GetExtension($f).ToLower(); switch($e){ '.html'{$t='text/html'} '.js'{$t='application/javascript'} '.css'{$t='text/css'} '.json'{$t='application/json'} '.geojson'{$t='application/geo+json'} default{$t='application/octet-stream'} }; $c.Response.ContentType=$t; $c.Response.OutputStream.Write($b,0,$b.Length) } else { $c.Response.StatusCode=404 }; $c.Response.Close() } } catch {}"
    timeout /t 2 >nul
    echo Application launched in browser.
    exit /b 0
)

:: Fallback if PowerShell is not present: open directly in Edge or Chrome with local file access
where msedge >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo Opening in Microsoft Edge App Mode...
    start "" msedge --allow-file-access-from-files --app="file:///%DIR:=/%index.html"
    exit /b 0
)

where chrome >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo Opening in Google Chrome App Mode...
    start "" chrome --allow-file-access-from-files --app="file:///%DIR:=/%index.html"
    exit /b 0
)

start "" "%DIR%index.html"
exit /b 0
