# TI Cycles Ambattur Tree Census GIS Launcher
Write-Host "==========================================================" -ForegroundColor Green
Write-Host "  TI CYCLES AMBATTUR - TREE CENSUS GIS LAUNCHER" -ForegroundColor Green
Write-Host "  Murugappa Group / Environmental & GIS Division" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Green

$port = 8899
$root = $PSScriptRoot

Write-Host "Starting lightweight local web server on port $port..." -ForegroundColor Yellow

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()

Start-Process "http://localhost:$port/index.html"
Write-Host "GIS Application opened in browser: http://localhost:$port/index.html" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop server..." -ForegroundColor Gray

while ($listener.IsListening) {
    $context = $listener.GetContext()
    $urlPath = $context.Request.Url.LocalPath.TrimStart('/')
    $filePath = Join-Path $root $urlPath
    if (-not (Test-Path $filePath) -or (Get-Item $filePath).PSIsContainer) {
        $filePath = Join-Path $root "index.html"
    }

    if (Test-Path $filePath) {
        $bytes = [System.IO.File]::ReadAllBytes($filePath)
        $context.Response.ContentLength64 = $bytes.Length
        $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
        switch ($ext) {
            ".html" { $context.Response.ContentType = "text/html" }
            ".js"   { $context.Response.ContentType = "application/javascript" }
            ".css"  { $context.Response.ContentType = "text/css" }
            ".json" { $context.Response.ContentType = "application/json" }
            ".geojson" { $context.Response.ContentType = "application/geo+json" }
            default { $context.Response.ContentType = "application/octet-stream" }
        }
        $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    } else {
        $context.Response.StatusCode = 404
    }
    $context.Response.Close()
}
